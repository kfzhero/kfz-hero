import { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';

export default function KfzHero() {
  const [step, setStep] = useState(1);
  const [vehicle, setVehicle] = useState({
    hersteller: '',
    modell: '',
    motorisierung: '',
    kba: ''
  });
  const [leistung, setLeistung] = useState('');
  const [plz, setPlz] = useState('');

  const werkstaetten = [
    {
      name: 'Autohaus Berlin GmbH',
      adresse: 'Musterstraße 1, 10115 Berlin',
      leistungen: ['Bremsbeläge wechseln', 'Ölwechsel'],
      preis: 'ab 129 €',
      zeiten: ['09:00', '13:00', '16:30']
    },
    {
      name: 'KFZ Meier & Söhne',
      adresse: 'Beispielweg 2, 10243 Berlin',
      leistungen: ['Zahnriemenwechsel', 'Batterietausch'],
      preis: 'ab 199 €',
      zeiten: ['08:30', '12:00', '15:00']
    }
  ];

  if (step === 1) {
    return (
      <div className="max-w-xl mx-auto p-4 space-y-4">
        <h1 className="text-2xl font-semibold">KFZ-Hero – Fahrzeugauswahl</h1>
        <Input placeholder="Hersteller (z.B. VW)" value={vehicle.hersteller} onChange={e => setVehicle({ ...vehicle, hersteller: e.target.value })} />
        <Input placeholder="Modell (z.B. Golf)" value={vehicle.modell} onChange={e => setVehicle({ ...vehicle, modell: e.target.value })} />
        <Input placeholder="Motorisierung (z.B. 2.0 TDI)" value={vehicle.motorisierung} onChange={e => setVehicle({ ...vehicle, motorisierung: e.target.value })} />
        <Input placeholder="KBA (optional)" value={vehicle.kba} onChange={e => setVehicle({ ...vehicle, kba: e.target.value })} />
        <Button onClick={() => setStep(2)}>Weiter zur Leistungsauswahl</Button>
      </div>
    );
  }

  if (step === 2) {
    return (
      <div className="max-w-xl mx-auto p-4 space-y-4">
        <h1 className="text-2xl font-semibold">Welche Reparaturleistung brauchst du?</h1>
        <Input placeholder="z.B. Bremsbeläge wechseln" value={leistung} onChange={e => setLeistung(e.target.value)} />
        <Input placeholder="Postleitzahl" value={plz} onChange={e => setPlz(e.target.value)} />
        <Button onClick={() => setStep(3)}>Werkstätten anzeigen</Button>
      </div>
    );
  }

  if (step === 3) {
    const gefiltert = werkstaetten.filter(w =>
      w.leistungen.includes(leistung)
    );

    return (
      <div className="max-w-3xl mx-auto p-4 space-y-4">
        <h1 className="text-2xl font-semibold mb-4">Werkstätten in deiner Nähe</h1>
        {gefiltert.length === 0 && <p>Keine passenden Werkstätten gefunden.</p>}
        {gefiltert.map((w, i) => (
          <Card key={i}>
            <CardContent className="p-4 space-y-2">
              <h2 className="text-xl font-bold">{w.name}</h2>
              <p>{w.adresse}</p>
              <p>Preis: {w.preis}</p>
              <p>Verfügbare Zeiten: {w.zeiten.join(', ')}</p>
              <Button>Buchen</Button>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  return null;
}
